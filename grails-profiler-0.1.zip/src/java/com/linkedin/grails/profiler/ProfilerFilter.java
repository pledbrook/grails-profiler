package com.linkedin.grails.profiler;

import org.codehaus.groovy.grails.web.servlet.FlashScope;
import org.codehaus.groovy.grails.web.servlet.mvc.GrailsWebRequest;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet filter that triggers profiling if a particular request
 * parameter is set ("profiler").
 */
public class ProfilerFilter extends OncePerRequestFilter {
    public static final String SAVED_OUTPUT_KEY = "com.linkedin.grails.profiler.saved_output";

    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain) throws ServletException, IOException {
        // Determine whether we should profile this request.
        boolean doProfiling = false;
        String profilerParam = request.getParameter("profiler");

        if (profilerParam != null && (profilerParam.equals("on") || profilerParam.equals("1"))) {
            doProfiling = true;
        }

        // If we are profiling, mark the request as such and log the
        // start time for this request.
        ProfilerLog profiler = null;
        RequestBufferedAppender appender = null;
        if (doProfiling) {
            // Fetch the currently configured logger for profiling from
            // the application context.
            WebApplicationContext appContext =
                    WebApplicationContextUtils.getRequiredWebApplicationContext(getServletContext());
            profiler = (ProfilerLog) appContext.getBean("profilerLog");

            // Check whether there is any saved output from a previous
            // request.
            FlashScope flash = getFlash(request);
            Object output = flash.get(SAVED_OUTPUT_KEY);
            if (output instanceof String) {
                // Add the saved output to the request buffered appender.
                appender = (RequestBufferedAppender) appContext.getBean("bufferedAppender");
                appender.prependOutput((String) output);
            }

            // Configure the profiler to log the start and end times.
            profiler.startProfiling("uri: " + request.getRequestURI());

            // Start time.
            profiler.logEntry(getClass(), "Web Request");
        }

        // Pass execution on to the next filter.
        try {
            filterChain.doFilter(request, response);
        }
        finally {
            // End time.
            if (doProfiling) {
                profiler.logExit(getClass(), "Web Request");
                profiler.stopProfiling();

                if (response.isCommitted()) {
                    // Save the log output to flash.
                    FlashScope flash = getFlash(request);
                    flash.put(SAVED_OUTPUT_KEY, appender.getOutput());
                }
            }
        }
    }

    /**
     * Returns the flash attached to the given request.
     */
    private FlashScope getFlash(HttpServletRequest request) {
        GrailsWebRequest requestAttributes = (GrailsWebRequest) RequestContextHolder.currentRequestAttributes();
        return requestAttributes.getAttributes().getFlashScope(request);
    }
}
